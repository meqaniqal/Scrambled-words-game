//
//  Scrambledwordsbegin2App.swift
//  Scrambledwordsbegin2
//
//  Created by Sheldon Lawrence on 3/3/25.
//

import SwiftUI

@main
struct Scrambledwordsfinalmkx: App {
    var body: some Scene {
        WindowGroup {
            GameView()
        }
    }
}
