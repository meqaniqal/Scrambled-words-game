//
//  LetterModel.swift
//  Scrambledwordsbegin2
//
//  Created by Sheldon Lawrence on 3/5/25.
//

import Foundation

struct Letter: Identifiable,Hashable {
    let id: Int
    var text: String
}
